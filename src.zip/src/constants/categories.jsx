export const categories = [
    { id: "electronics", label: "Electronics" },
    { id: "furniture", label: "Furniture" },
    { id: "books", label: "Books" },
    { id: "vehicles", label: "Vehicles" },
    { id: "tools", label: "Tools" },
    { id: "others", label: "Others" }
];

